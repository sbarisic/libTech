
#pragma once

#include <cstdlib>
#include "../core/Shape.h"

namespace msdfgen {

	class FreetypeHandle;
	class FontHandle;

#pragma pack(push, 1)
	struct FontCharacter {
		void* BitmapPtr;

		int Width;
		int Height;

		int BearingX;
		int BearingY;

		int AdvanceX;
		int AdvanceY;

		int PixelMode;
	};
#pragma pack(pop)

	/// Initializes the FreeType library
	FreetypeHandle * initializeFreetype();
	/// Deinitializes the FreeType library
	void deinitializeFreetype(FreetypeHandle *library);
	/// Loads a font file and returns its handle
	FontHandle * loadFont(FreetypeHandle *library, const char *filename);
	/// Loads a font file from memory
	FontHandle* loadFontMemory(FreetypeHandle* library, void* mem, int len);
	/// Unloads a font file
	void destroyFont(FontHandle *font);
	/// Returns the size of one EM in the font's coordinate system
	bool getFontScale(double &output, FontHandle *font);
	/// Returns the width of space and tab
	bool getFontWhitespaceWidth(double &spaceAdvance, double &tabAdvance, FontHandle *font);
	/// Loads the shape prototype of a glyph from font file
	bool loadGlyph(Shape &output, FontHandle *font, int unicode, double *advance = NULL);
	/// Returns the kerning distance adjustment between two specific glyphs.
	bool getKerning(double &output, FontHandle *font, unsigned long unicode1, unsigned long unicode2);


	bool loadGlyphNormal(FontHandle* Font, unsigned long Unicode, FontCharacter* OutChar);

	bool setFontSize(FontHandle* Font, int W, int H);
}
